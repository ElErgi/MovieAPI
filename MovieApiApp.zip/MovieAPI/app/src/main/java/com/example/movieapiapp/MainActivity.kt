import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private val BASE_URL = "https://api.themoviedb.org/3/"
    private val API_KEY = "46e84f74bc34f68f997c0d56cb068f64" // Reemplaza con tu propia clave API

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.example.movieapiapp.R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(com.example.movieapiapp.R.id.list)
        recyclerView.layoutManager = GridLayoutManager(this, 2)

        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(MovieApiService::class.java)
        val call = service.getPopularMovies()

        call.enqueue(object : Callback<MovieResponse> {
            override fun onResponse(call: Call<MovieResponse>, response: Response<MovieResponse>) {
                if (response.isSuccessful) {
                    val movies = response.body()?.results ?: emptyList()
                    val films = movies.map { Movie(it.title, it.posterPath) }
                    recyclerView.adapter = FilmsAdapter(films)
                }
            }

            override fun onFailure(call: Call<MovieResponse>, t: Throwable) {
                // Manejar la falla de la llamada a la API
            }
        })
    }
}
