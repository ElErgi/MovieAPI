import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.movieapiapp.R

class MovieDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_details)

        // Recuperar detalles de la película del Intent
        val filmName = intent.getStringExtra("film_name")
        val filmReleaseDate = intent.getStringExtra("film_release_date")
        val filmOverview = intent.getStringExtra("film_overview")

        // Obtener referencias a los elementos de la interfaz de usuario
        val imageViewMovie: ImageView = findViewById(R.id.imageViewMovie)
        val textViewName: TextView = findViewById(R.id.textViewName)
        val textViewReleaseDate: TextView = findViewById(R.id.textViewReleaseDate)
        val textViewOverview: TextView = findViewById(R.id.textViewOverview)

        // Configurar los valores en los elementos de la interfaz de usuario
        textViewName.text = filmName
        textViewReleaseDate.text = filmReleaseDate
        textViewOverview.text = filmOverview
    }
}