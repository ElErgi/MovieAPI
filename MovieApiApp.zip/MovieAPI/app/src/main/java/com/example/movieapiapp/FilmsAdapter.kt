import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.movieapiapp.R

class FilmsAdapter(private val mFilms: List<Movie>) : RecyclerView.Adapter<FilmsAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.text2)
        val image: ImageView = itemView.findViewById(R.id.image)

        init {
            itemView.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val clickedFilm = mFilms[position]

                    val intent = Intent(itemView.context, MovieDetailsActivity::class.java).apply {
                        putExtra("film_name", clickedFilm.name)
                        putExtra("film_image", clickedFilm.image)
                        putExtra("film_release_date", clickedFilm.releaseDate)
                        putExtra("film_overview", clickedFilm.overview)
                    }

                    itemView.context.startActivity(intent)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        TODO("Not yet implemented")
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        TODO("Not yet implemented")
    }

    // Resto del código del adaptador
}
