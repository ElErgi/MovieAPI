package com.example.movieapiapp

class DetailsAdapter {
}