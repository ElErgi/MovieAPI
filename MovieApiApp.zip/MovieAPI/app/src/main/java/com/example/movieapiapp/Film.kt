package com.example.movieapiapp

class Film(val name: String, val image: String, val releaseDate: String, val overview: String) {
}